var searchData=
[
  ['sender',['sender',['../structmessage__hdr__t.html#a6aa18d82629c912fe68c229936b87c77',1,'message_hdr_t']]],
  ['sigstop',['sigstop',['../chatty_8c.html#af6f442f95834df16503f6ab840baef8b',1,'chatty.c']]],
  ['sigusr',['sigusr',['../chatty_8c.html#ae1478d8479e5b100da5df8e392d26a94',1,'chatty.c']]],
  ['size',['size',['../structoperation__t.html#a37363161b41c4165b98cba7abc7a9d95',1,'operation_t::size()'],['../structuserdata.html#a439227feff9d7f55384e8780cfc2eb82',1,'userdata::size()']]],
  ['sname',['sname',['../structoperation__t.html#a596940e8f95dfc43bb298b5e8148c770',1,'operation_t']]],
  ['statfilename',['StatFileName',['../structconf__values.html#a76aa48db65fcc5da8f8cecc5eff66104',1,'conf_values']]]
];
