var searchData=
[
  ['fd',['fd',['../structnode.html#a6f8059414f0228f0256115e024eeed4b',1,'node::fd()'],['../structuserdata.html#a6f8059414f0228f0256115e024eeed4b',1,'userdata::fd()']]],
  ['file_5fmessage',['FILE_MESSAGE',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca114675ea37d79ff22f18645a7ba2dc73',1,'ops.h']]],
  ['free_5fuserdata',['free_userdata',['../user_8h.html#affaab1479cae635872603f5717e98490',1,'free_userdata(void *usrdt):&#160;user.c'],['../user_8c.html#affaab1479cae635872603f5717e98490',1,'free_userdata(void *usrdt):&#160;user.c']]]
];
