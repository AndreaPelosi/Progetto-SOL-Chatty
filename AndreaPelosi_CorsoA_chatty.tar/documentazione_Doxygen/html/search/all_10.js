var searchData=
[
  ['read_5fbit',['read_bit',['../structhistory.html#a37d36c29d3889c19215e2a3bc11cdad3',1,'history']]],
  ['readdata',['readData',['../connections_8c.html#acf5cb8379636265d11a008d6aa94dc30',1,'readData(long fd, message_data_t *data):&#160;connections.c'],['../connections_8h.html#acf5cb8379636265d11a008d6aa94dc30',1,'readData(long fd, message_data_t *data):&#160;connections.c']]],
  ['readdataheader',['readDataHeader',['../connections_8c.html#abb971a8884cfa613e0d4cc3f7b401481',1,'readDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c'],['../connections_8h.html#abb971a8884cfa613e0d4cc3f7b401481',1,'readDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c']]],
  ['readheader',['readHeader',['../connections_8c.html#a2a15cc3debfd6700ea0f40a198c55c85',1,'readHeader(long connfd, message_hdr_t *hdr):&#160;connections.c'],['../connections_8h.html#a2a15cc3debfd6700ea0f40a198c55c85',1,'readHeader(long connfd, message_hdr_t *hdr):&#160;connections.c']]],
  ['readmsg',['readMsg',['../connections_8c.html#a2fc6b845d44636fb241a848e58c83420',1,'readMsg(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a2fc6b845d44636fb241a848e58c83420',1,'readMsg(long fd, message_t *msg):&#160;connections.c']]],
  ['receiver',['receiver',['../structmessage__data__hdr__t.html#aabb098b2d9fd9305abddad8893b38843',1,'message_data_hdr_t']]],
  ['register_5fop',['REGISTER_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44caf36690799901b259e0db234a04fc2969',1,'ops.h']]],
  ['retrieve_5ffrom_5fhistory',['retrieve_from_history',['../user_8h.html#ad8bb3d703ef33f939bb50b184dbacddb',1,'retrieve_from_history(user_data_t *usrdt, int index, int *read_now):&#160;user.c'],['../user_8c.html#ad8bb3d703ef33f939bb50b184dbacddb',1,'retrieve_from_history(user_data_t *usrdt, int index, int *read_now):&#160;user.c']]],
  ['rname',['rname',['../structoperation__t.html#a4abc08d8bf8e71d81f1928b77675d9a8',1,'operation_t']]]
];
