var searchData=
[
  ['op',['op',['../structoperation__t.html#a26b2efa792334cce1cd82d1c63754539',1,'operation_t::op()'],['../structmessage__hdr__t.html#a26b2efa792334cce1cd82d1c63754539',1,'message_hdr_t::op()']]]
];
