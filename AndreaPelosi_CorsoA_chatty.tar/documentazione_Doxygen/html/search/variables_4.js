var searchData=
[
  ['fd',['fd',['../structnode.html#a6f8059414f0228f0256115e024eeed4b',1,'node::fd()'],['../structuserdata.html#a6f8059414f0228f0256115e024eeed4b',1,'userdata::fd()']]]
];
