var searchData=
[
  ['deletefdfromlist',['deleteFdFromList',['../liste_8h.html#a6e6314a847c0408e40e84a5d92104bbe',1,'deleteFdFromList(list_t *L, int fd):&#160;liste.c'],['../liste_8c.html#a6e6314a847c0408e40e84a5d92104bbe',1,'deleteFdFromList(list_t *L, int fd):&#160;liste.c']]],
  ['deletenamefromlist',['deleteNameFromList',['../liste_8h.html#a8eb7bcacc21039f8d0746978c35ef195',1,'deleteNameFromList(list_t *L, const char *str):&#160;liste.c'],['../liste_8c.html#a8eb7bcacc21039f8d0746978c35ef195',1,'deleteNameFromList(list_t *L, const char *str):&#160;liste.c']]],
  ['destroylist',['destroyList',['../liste_8h.html#a5da479cbc8aaeeb555c099174e419f3d',1,'destroyList(list_t *L):&#160;liste.c'],['../liste_8c.html#a5da479cbc8aaeeb555c099174e419f3d',1,'destroyList(list_t *L):&#160;liste.c']]]
];
