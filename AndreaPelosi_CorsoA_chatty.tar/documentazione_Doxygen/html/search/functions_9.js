var searchData=
[
  ['readdata',['readData',['../connections_8c.html#acf5cb8379636265d11a008d6aa94dc30',1,'readData(long fd, message_data_t *data):&#160;connections.c'],['../connections_8h.html#acf5cb8379636265d11a008d6aa94dc30',1,'readData(long fd, message_data_t *data):&#160;connections.c']]],
  ['readdataheader',['readDataHeader',['../connections_8c.html#abb971a8884cfa613e0d4cc3f7b401481',1,'readDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c'],['../connections_8h.html#abb971a8884cfa613e0d4cc3f7b401481',1,'readDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c']]],
  ['readheader',['readHeader',['../connections_8c.html#a2a15cc3debfd6700ea0f40a198c55c85',1,'readHeader(long connfd, message_hdr_t *hdr):&#160;connections.c'],['../connections_8h.html#a2a15cc3debfd6700ea0f40a198c55c85',1,'readHeader(long connfd, message_hdr_t *hdr):&#160;connections.c']]],
  ['readmsg',['readMsg',['../connections_8c.html#a2fc6b845d44636fb241a848e58c83420',1,'readMsg(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a2fc6b845d44636fb241a848e58c83420',1,'readMsg(long fd, message_t *msg):&#160;connections.c']]],
  ['retrieve_5ffrom_5fhistory',['retrieve_from_history',['../user_8h.html#ad8bb3d703ef33f939bb50b184dbacddb',1,'retrieve_from_history(user_data_t *usrdt, int index, int *read_now):&#160;user.c'],['../user_8c.html#ad8bb3d703ef33f939bb50b184dbacddb',1,'retrieve_from_history(user_data_t *usrdt, int index, int *read_now):&#160;user.c']]]
];
