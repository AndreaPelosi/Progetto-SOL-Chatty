var searchData=
[
  ['userdata',['userdata',['../structuserdata.html',1,'']]]
];
