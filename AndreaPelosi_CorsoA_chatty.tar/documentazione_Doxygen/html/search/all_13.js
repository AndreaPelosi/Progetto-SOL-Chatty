var searchData=
[
  ['unix_5fpath_5fmax',['UNIX_PATH_MAX',['../config_8h.html#a7baab2aa5bf8eb14b6128e0f16634837',1,'UNIX_PATH_MAX():&#160;config.h'],['../connections_8h.html#a7baab2aa5bf8eb14b6128e0f16634837',1,'UNIX_PATH_MAX():&#160;connections.h']]],
  ['unixpath',['UnixPath',['../structconf__values.html#ab13f2c10dc85ac86a157ab17f7559e9f',1,'conf_values']]],
  ['unregister_5fop',['UNREGISTER_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cabc2ab44946aad99a4cda3f0e4abb5b5a',1,'ops.h']]],
  ['update_5fstats',['update_stats',['../chatty_8c.html#a81dc54a86570a6be33a82c36421132cb',1,'chatty.c']]],
  ['update_5fuser_5ffd',['update_user_fd',['../user_8h.html#ab74fd730280d267439b5c89ea6101b48',1,'update_user_fd(user_data_t *usrdt, int new_fd):&#160;user.c'],['../user_8c.html#ab74fd730280d267439b5c89ea6101b48',1,'update_user_fd(user_data_t *usrdt, int new_fd):&#160;user.c']]],
  ['user_2ec',['user.c',['../user_8c.html',1,'']]],
  ['user_2eh',['user.h',['../user_8h.html',1,'']]],
  ['user_5fdata_5finit',['user_data_init',['../user_8h.html#a600db360f21146881a3552de8e38d302',1,'user_data_init(user_data_t *usrdt, char *username, int fd, int MaxMsgSize, int MaxFileSize, int MaxHistMsgs):&#160;user.c'],['../user_8c.html#a600db360f21146881a3552de8e38d302',1,'user_data_init(user_data_t *usrdt, char *username, int fd, int MaxMsgSize, int MaxFileSize, int MaxHistMsgs):&#160;user.c']]],
  ['user_5fdata_5ft',['user_data_t',['../user_8h.html#af5503eb8b2ba5c9249d747689d2655bd',1,'user.h']]],
  ['userdata',['userdata',['../structuserdata.html',1,'']]],
  ['username',['username',['../structuserdata.html#a9b20c006bd90a09e1465fb668700e81d',1,'userdata']]],
  ['usrlist_5fop',['USRLIST_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca76c5f8cf5dd046fbfe3f0b6a7bce8e90',1,'ops.h']]]
];
