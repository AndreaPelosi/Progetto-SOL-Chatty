var searchData=
[
  ['senddata',['sendData',['../connections_8c.html#aa7805c42a47eb013344c0ceb6b3533e8',1,'sendData(long fd, message_data_t *data):&#160;connections.c'],['../connections_8h.html#a7812cf59eeeaa63ce7d7b9ce93125462',1,'sendData(long fd, message_data_t *msg):&#160;connections.c']]],
  ['senddataheader',['sendDataHeader',['../connections_8c.html#ac7851908b05c8bb05b32a6da877bef9f',1,'sendDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c'],['../connections_8h.html#ac7851908b05c8bb05b32a6da877bef9f',1,'sendDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c']]],
  ['sendheader',['sendHeader',['../connections_8c.html#a76519996d7c1c002a8214e8ba40af51c',1,'sendHeader(long fd, message_hdr_t *hdr):&#160;connections.c'],['../connections_8h.html#a1a3f1d447f26575379802386e4cb1587',1,'sendHeader(long fd, message_hdr_t *msg):&#160;connections.c']]],
  ['sendrequest',['sendRequest',['../connections_8c.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c']]],
  ['sig_5fmanager',['sig_manager',['../chatty_8c.html#a5b9e81f91edf08e29fad06956be3be9e',1,'chatty.c']]],
  ['stats_5fhandler',['stats_handler',['../chatty_8c.html#af512505b89f958808e50386e987fc25b',1,'chatty.c']]]
];
