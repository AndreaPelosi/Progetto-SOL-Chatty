var searchData=
[
  ['openconnection',['openConnection',['../connections_8c.html#a93ad31c416b2e2055827e5f684e89daf',1,'openConnection(char *path, unsigned int ntimes, unsigned int secs):&#160;connections.c'],['../connections_8h.html#a93ad31c416b2e2055827e5f684e89daf',1,'openConnection(char *path, unsigned int ntimes, unsigned int secs):&#160;connections.c']]]
];
