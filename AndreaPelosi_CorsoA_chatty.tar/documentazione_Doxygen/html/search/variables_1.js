var searchData=
[
  ['chattystats',['chattyStats',['../chatty_8c.html#a9e4166354e886d074465ab1bb87ca0e2',1,'chatty.c']]]
];
