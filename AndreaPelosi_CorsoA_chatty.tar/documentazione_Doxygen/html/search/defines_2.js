var searchData=
[
  ['connections_5fc_5f',['CONNECTIONS_C_',['../connections_8c.html#a0eb53c37bcc5a621d4d8a33bbe18b8dc',1,'connections.c']]]
];
