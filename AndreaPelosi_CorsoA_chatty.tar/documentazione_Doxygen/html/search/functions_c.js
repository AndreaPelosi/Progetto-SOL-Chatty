var searchData=
[
  ['update_5fstats',['update_stats',['../chatty_8c.html#a81dc54a86570a6be33a82c36421132cb',1,'chatty.c']]],
  ['update_5fuser_5ffd',['update_user_fd',['../user_8h.html#ab74fd730280d267439b5c89ea6101b48',1,'update_user_fd(user_data_t *usrdt, int new_fd):&#160;user.c'],['../user_8c.html#ab74fd730280d267439b5c89ea6101b48',1,'update_user_fd(user_data_t *usrdt, int new_fd):&#160;user.c']]],
  ['user_5fdata_5finit',['user_data_init',['../user_8h.html#a600db360f21146881a3552de8e38d302',1,'user_data_init(user_data_t *usrdt, char *username, int fd, int MaxMsgSize, int MaxFileSize, int MaxHistMsgs):&#160;user.c'],['../user_8c.html#a600db360f21146881a3552de8e38d302',1,'user_data_init(user_data_t *usrdt, char *username, int fd, int MaxMsgSize, int MaxFileSize, int MaxHistMsgs):&#160;user.c']]]
];
