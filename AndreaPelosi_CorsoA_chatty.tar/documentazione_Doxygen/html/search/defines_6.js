var searchData=
[
  ['max_5fconf_5ffile_5fline_5fsize',['MAX_CONF_FILE_LINE_SIZE',['../conf__parsing_8h.html#adbc75a6b171948b6976db6fdcfe582f9',1,'conf_parsing.h']]],
  ['max_5fname_5flength',['MAX_NAME_LENGTH',['../config_8h.html#a0c397a708cec89c74029582574516b30',1,'config.h']]],
  ['max_5fretries',['MAX_RETRIES',['../connections_8h.html#aecf13b8dc783db2202ca5c34fe117fc3',1,'connections.h']]],
  ['max_5fsleeping',['MAX_SLEEPING',['../connections_8h.html#a763a071b50fb9cf7997861d0f5266387',1,'connections.h']]]
];
