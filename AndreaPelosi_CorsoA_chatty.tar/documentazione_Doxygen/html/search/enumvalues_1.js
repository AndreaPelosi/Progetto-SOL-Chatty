var searchData=
[
  ['connect_5fop',['CONNECT_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cab602ddf0795d3c4dc2fd0b4b957ba988',1,'ops.h']]],
  ['creategroup_5fop',['CREATEGROUP_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca30840713ad9050c2d275b31ff8404313',1,'ops.h']]]
];
