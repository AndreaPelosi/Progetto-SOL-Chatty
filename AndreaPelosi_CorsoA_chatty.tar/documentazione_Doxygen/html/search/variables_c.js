var searchData=
[
  ['read_5fbit',['read_bit',['../structhistory.html#a37d36c29d3889c19215e2a3bc11cdad3',1,'history']]],
  ['receiver',['receiver',['../structmessage__data__hdr__t.html#aabb098b2d9fd9305abddad8893b38843',1,'message_data_hdr_t']]],
  ['rname',['rname',['../structoperation__t.html#a4abc08d8bf8e71d81f1928b77675d9a8',1,'operation_t']]]
];
