var searchData=
[
  ['txt_5fmessage',['TXT_MESSAGE',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cae8592a49ed69355669ec14cdb03291ea',1,'ops.h']]]
];
