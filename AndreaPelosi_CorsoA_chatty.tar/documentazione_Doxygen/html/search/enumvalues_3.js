var searchData=
[
  ['file_5fmessage',['FILE_MESSAGE',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca114675ea37d79ff22f18645a7ba2dc73',1,'ops.h']]]
];
