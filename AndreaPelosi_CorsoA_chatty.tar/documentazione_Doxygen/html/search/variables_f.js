var searchData=
[
  ['unixpath',['UnixPath',['../structconf__values.html#ab13f2c10dc85ac86a157ab17f7559e9f',1,'conf_values']]],
  ['username',['username',['../structuserdata.html#a9b20c006bd90a09e1465fb668700e81d',1,'userdata']]]
];
