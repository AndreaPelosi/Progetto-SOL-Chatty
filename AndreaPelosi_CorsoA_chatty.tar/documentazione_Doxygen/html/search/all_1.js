var searchData=
[
  ['add_5fto_5fhistory',['add_to_history',['../user_8h.html#a2af0f9efcf699c45971b83332139cfe0',1,'add_to_history(user_data_t *usrdt, message_t *msg_to_add, int read, int already_locked):&#160;user.c'],['../user_8c.html#a2af0f9efcf699c45971b83332139cfe0',1,'add_to_history(user_data_t *usrdt, message_t *msg_to_add, int read, int already_locked):&#160;user.c']]],
  ['add_5fto_5fhistory_5fall',['add_to_history_all',['../user_8h.html#abe5db7757352fba7382568f36da547c6',1,'add_to_history_all(icl_hash_t *hashtable, char *user, message_t *msg_to_add, int *nonline, int *noffline):&#160;user.c'],['../user_8c.html#abe5db7757352fba7382568f36da547c6',1,'add_to_history_all(icl_hash_t *hashtable, char *user, message_t *msg_to_add, int *nonline, int *noffline):&#160;user.c']]],
  ['addgroup_5fop',['ADDGROUP_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca30f53d46265f83a2b0a14d6486a450d5',1,'ops.h']]]
];
