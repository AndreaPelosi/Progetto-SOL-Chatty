var searchData=
[
  ['word',['word',['../structnode.html#ac00a4258bfdabd98aca279382135ec92',1,'node']]]
];
