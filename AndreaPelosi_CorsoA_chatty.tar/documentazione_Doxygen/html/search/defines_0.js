var searchData=
[
  ['_5fposix_5fc_5fsource',['_POSIX_C_SOURCE',['../chatty_8c.html#a3024ccd4a9af5109d24e6c57565d74a1',1,'_POSIX_C_SOURCE():&#160;chatty.c'],['../client_8c.html#a3024ccd4a9af5109d24e6c57565d74a1',1,'_POSIX_C_SOURCE():&#160;client.c']]]
];
