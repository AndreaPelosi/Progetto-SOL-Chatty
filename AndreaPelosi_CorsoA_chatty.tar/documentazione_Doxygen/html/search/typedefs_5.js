var searchData=
[
  ['user_5fdata_5ft',['user_data_t',['../user_8h.html#af5503eb8b2ba5c9249d747689d2655bd',1,'user.h']]]
];
