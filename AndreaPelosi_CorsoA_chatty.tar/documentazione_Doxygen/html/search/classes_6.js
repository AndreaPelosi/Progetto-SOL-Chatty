var searchData=
[
  ['operation_5ft',['operation_t',['../structoperation__t.html',1,'']]]
];
