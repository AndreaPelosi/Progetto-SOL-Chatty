var searchData=
[
  ['senddata',['sendData',['../connections_8c.html#aa7805c42a47eb013344c0ceb6b3533e8',1,'sendData(long fd, message_data_t *data):&#160;connections.c'],['../connections_8h.html#a7812cf59eeeaa63ce7d7b9ce93125462',1,'sendData(long fd, message_data_t *msg):&#160;connections.c']]],
  ['senddataheader',['sendDataHeader',['../connections_8c.html#ac7851908b05c8bb05b32a6da877bef9f',1,'sendDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c'],['../connections_8h.html#ac7851908b05c8bb05b32a6da877bef9f',1,'sendDataHeader(long fd, message_data_hdr_t *data_hdr):&#160;connections.c']]],
  ['sender',['sender',['../structmessage__hdr__t.html#a6aa18d82629c912fe68c229936b87c77',1,'message_hdr_t']]],
  ['sendheader',['sendHeader',['../connections_8c.html#a76519996d7c1c002a8214e8ba40af51c',1,'sendHeader(long fd, message_hdr_t *hdr):&#160;connections.c'],['../connections_8h.html#a1a3f1d447f26575379802386e4cb1587',1,'sendHeader(long fd, message_hdr_t *msg):&#160;connections.c']]],
  ['sendrequest',['sendRequest',['../connections_8c.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c']]],
  ['sig_5fmanager',['sig_manager',['../chatty_8c.html#a5b9e81f91edf08e29fad06956be3be9e',1,'chatty.c']]],
  ['sigstop',['sigstop',['../chatty_8c.html#af6f442f95834df16503f6ab840baef8b',1,'chatty.c']]],
  ['sigusr',['sigusr',['../chatty_8c.html#ae1478d8479e5b100da5df8e392d26a94',1,'chatty.c']]],
  ['size',['size',['../structoperation__t.html#a37363161b41c4165b98cba7abc7a9d95',1,'operation_t::size()'],['../structuserdata.html#a439227feff9d7f55384e8780cfc2eb82',1,'userdata::size()']]],
  ['sname',['sname',['../structoperation__t.html#a596940e8f95dfc43bb298b5e8148c770',1,'operation_t']]],
  ['statfilename',['StatFileName',['../structconf__values.html#a76aa48db65fcc5da8f8cecc5eff66104',1,'conf_values']]],
  ['statistics',['statistics',['../structstatistics.html',1,'']]],
  ['stats',['stats',['../stats_8h.html#aa57ebe01934de43865125819a3c4af74',1,'stats.h']]],
  ['stats_2eh',['stats.h',['../stats_8h.html',1,'']]],
  ['stats_5fhandler',['stats_handler',['../chatty_8c.html#af512505b89f958808e50386e987fc25b',1,'chatty.c']]]
];
